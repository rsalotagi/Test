package com.raghu.anagram.Anagram;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Anagram {
	public static void main(String[] args) {

		printAnagrams();
	}

	public static void printAnagrams() {
		Scanner s = null;
		Scanner input = null;
		try {
			// Read the file from the Class Path Resource
			InputStream stream = Anagram.class.getResourceAsStream("/words.txt");
			s = new Scanner(stream);

			// Add the words to the List
			ArrayList<String> words = new ArrayList<String>();
			while (s.hasNext()) {
				words.add(s.next());
			}

			HashMap<String, ArrayList<String>> map = new HashMap<>();

			// Loop through the list of words and convert to charArray and sort
			// it
			for (String str : words) {
				char[] temp = str.toCharArray();
				Arrays.sort(temp);
				String key = new String(temp).toLowerCase();
				if (map.get(key) != null) { // If String found the map then get
											// the key and add to that list
					map.get(key).add(str.toLowerCase());
				} else {
					// If String not found in Map the create new list and add to
					// list and put to the map
					ArrayList<String> anagramList = new ArrayList<>();
					anagramList.add(str);
					map.put(key, anagramList);
				}
				Collections.sort(map.get(key));// Inorder to sort on the alphabetical order
			}

			input = new Scanner(System.in);
			System.out.println("Enter the word to find the anagrams");
			String str = input.nextLine();
			char[] key = str.toCharArray();
			Arrays.sort(key);
			str = new String(key).toLowerCase();
			if (!map.containsKey(str)) {
				System.out.print("word not found in the file");
			} else if (map.get(str).size() != 1) {
				for (String p : map.get(str)) {
					System.out.print(p + " ");
				}
			} else {
				System.out.print("No anagrams found");
			}
		} catch (Exception e) {
			System.out.print("Some Exception occured ");
			e.printStackTrace();
		} finally {
			s.close();
			input.close();
		}
	}
}
